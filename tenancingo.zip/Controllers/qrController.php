<?php 
require_once '../models/qrModel.php';




?>