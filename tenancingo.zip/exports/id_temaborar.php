<?php 

// Mover los temas a id_tema


// Avances del Foda por Area 


// crear propuesta de tabla para reporte trimestral del Informe de Gobierno


// agregar un campo a Actividades para claves de copladem


// agregar año a las tablas Avances y Avances Indicadores


// cambiar año y mes a INT



?>