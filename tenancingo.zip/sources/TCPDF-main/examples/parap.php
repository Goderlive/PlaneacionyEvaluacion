
<div style="height: 100%; background-image: url(images/back-FUAT2.jpg);">
    <table style="border: 1px solid black; background-color: #ffffff">
        <tr>
            <td>    
                <table>
                    <tr>
                        <td>
                            <br>
                            Actividades
                            <br>
                            Actividades
                            <br>
                            Actividades
                            <br>
                            Actividades
                            <br>
                            Actividades
                            <br>
                            Actividades
                        </td>
                    </tr>
                </table>
            </td>    
            <td>    
                <table>
                    <tr>
                        <td>
                            <br>
                            Indicadores
                        </td>
                    </tr>
                </table>
            </td>    
        </tr>
    </table>
<div>