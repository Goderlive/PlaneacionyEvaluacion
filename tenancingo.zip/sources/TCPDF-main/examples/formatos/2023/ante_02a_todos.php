<?php
session_start();

// Include the main TCPDF library (search for installation path).
require_once('../../tcpdf_include.php');
require_once '../../../../../models/conection.php';

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->setAuthor('');
$pdf->setTitle('02a');
$pdf->setSubject('');
$pdf->setKeywords('TCPDF, PDF, example, test, guide');

// set default header data
$pdf->SetPrintHeader(false);
$pdf->SetPrintFooter(false);
// set header and footer fonts

// set default monospaced font
$pdf->setDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins

// set auto page breaks

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)

// set font
$pdf->setFont('dejavusans', '', 10);


function traeAnteActividades($con, $id_area)
{
    $consulta = "SELECT li.clave_linea, a.*, ap.*, u.*, p.enero as ene, p.febrero as feb, p.marzo as mar, p.abril as abr, p.mayo as may, p.junio as jun, p.julio as jul, p.agosto as ago, p.septiembre as sep, p.octubre as oct, p.noviembre as nov, p.diciembre as dic
    FROM ante_actividades a
    LEFT JOIN unidades_medida u ON u.id_unidad = a.id_unidad
    LEFT JOIN ante_programaciones ap ON ap.id_actividad = a.id_actividad
    LEFT JOIN programaciones p ON p.id_actividad = a.id_actividad
    LEFT JOIN lineasactividades la ON la.id_actividad = a.id_actividad
    LEFT JOIN pdm_lineas li ON li.id_linea = la.id_linea
    WHERE id_area = $id_area
    GROUP BY a.id_actividad
    ORDER BY  CONVERT(codigo_actividad, UNSIGNED) ASC";

    $stm = $con->query($consulta);
    $actividades = $stm->fetchAll(PDO::FETCH_ASSOC);

    return $actividades;
}

function generaRenglon($con, $anteActividades)
{
    $renglon = '';
    foreach ($anteActividades as $a) {

        $progAnte = $a['enero'] + $a['febrero'] + $a['marzo'] + $a['abril'] + $a['mayo'] + $a['junio'] + $a['julio'] + $a['agosto'] + $a['septiembre'] + $a['octubre'] + $a['noviembre'] + $a['diciembre'];
        $prog1er = $a['enero'] + $a['febrero'] + $a['marzo'];
        $prog2do = $a['abril'] + $a['mayo'] + $a['junio'];
        $prog3er = $a['julio'] + $a['agosto'] + $a['septiembre'];
        $prog4to = $a['octubre'] + $a['noviembre'] + $a['diciembre'];

        if ($progAnte != 0) {
            $porcentual1 = number_format(($prog1er / $progAnte) * 100, 1) . '%';
            $porcentual2 = number_format(($prog2do / $progAnte) * 100, 1) . '%';
            $porcentual3 = number_format(($prog3er / $progAnte) * 100, 1) . '%';
            $porcentual4 = number_format(($prog4to / $progAnte) * 100, 1) . '%';
        } else {
            $porcentual1 = "0%";
            $porcentual2 = "0%";
            $porcentual3 = "0%";
            $porcentual4 = "0%";
        }

        $renglon .= '<tr>';
        $renglon .= '<td style="text-align: center; border:1px solid gray; font-size: 7px">' . $a['codigo_actividad'] . '</td>';
        $renglon .= '<td style="text-align: left; border:1px solid gray; font-size: 7px">' . $a['nombre_actividad'] . ' <br> ' . $a['clave_linea'] . '</td>';
        $renglon .= '<td style="text-align: center; border:1px solid gray; font-size: 7px">' . $a['nombre_unidad'] . '</td>';
        $renglon .= '<td style="text-align: center; border:1px solid gray; font-size: 7px">' . $progAnte . '</td>';
        $renglon .= '<td style="text-align: center; border:1px solid gray; font-size: 7px">' . $prog1er . '</td>';
        $renglon .= '<td style="text-align: center; border:1px solid gray; font-size: 7px">' . $porcentual1 . '</td>';
        $renglon .= '<td style="text-align: center; border:1px solid gray; font-size: 7px">' . $prog2do . '</td>';
        $renglon .= '<td style="text-align: center; border:1px solid gray; font-size: 7px">' . $porcentual2 . '</td>';
        $renglon .= '<td style="text-align: center; border:1px solid gray; font-size: 7px">' . $prog3er . '</td>';
        $renglon .= '<td style="text-align: center; border:1px solid gray; font-size: 7px">' . $porcentual3 . '</td>';
        $renglon .= '<td style="text-align: center; border:1px solid gray; font-size: 7px">' . $prog4to . '</td>';
        $renglon .= '<td style="text-align: center; border:1px solid gray; font-size: 7px">' . $porcentual4 . '</td>';
        $renglon .= '</tr>';
    }

    return $renglon;
}


$consulta = "SELECT *, ar.id_dependencia as id_dependencia, ar.id_area as id_area FROM ante_areas ar
LEFT JOIN dependencias_generales ON ar.id_dependencia_general = dependencias_generales.id_dependencia 
LEFT JOIN dependencias_auxiliares ON ar.id_dependencia_aux = dependencias_auxiliares.id_dependencia_auxiliar 
LEFT JOIN proyectos ON ar.id_proyecto = proyectos.id_proyecto 
LEFT JOIN programas_presupuestarios ON proyectos.id_programa = programas_presupuestarios.id_programa 
LEFT JOIN dependencias ON ar.id_dependencia = dependencias.id_dependencia
LEFT JOIN titulares ON titulares.id_area = ar.id_area
GROUP BY ar.id_area";
$stm = $con->query($consulta);
$areas = $stm->fetchAll(PDO::FETCH_ASSOC);


function traeDirector($con, $id_dependencia)
{
    $stm = $con->query("SELECT * FROM titulares WHERE id_dependencia = $id_dependencia");
    $Director = $stm->fetch(PDO::FETCH_ASSOC);
    if ($Director) {
        return $Director;
    } else {
        return array("id_titular" => 0, "nombre" => " ", "apellidos" => " ", "cargo" => " ", "gradoa" => " ", "id_area" => NULL, "id_registrante" => 0, "fecha_alta" => "", "id_dependencia" => 0);
    }
}

$stm = $con->query("SELECT * FROM setings a
JOIN titulares t ON t.id_titular = a.id_uippe");
$DirectorUIPPE = $stm->fetch(PDO::FETCH_ASSOC);


$anio = $_SESSION['anio'];
$sqlajustes = $con->query("SELECT * FROM setings WHERE year_report = $anio");
$ajustes = $sqlajustes->fetch(PDO::FETCH_ASSOC);
$escudo = '../../../../../' . $ajustes['path_logo_ayuntamiento'];
$administracion = '../../../../../' . $ajustes['path_logo_administracion'];




foreach ($areas as $a) {
    $Director = traeDirector($con, $a['id_dependencia']);

    $anteActividades = traeAnteActividades($con, $a['id_area']);

    $renglon = generaRenglon($con, $anteActividades);


    // add a page
    $pdf->AddPage();
    $html0 = '
        <table style="width:100%;">
            <tbody>
                <tr>
                    <td style="width:15%; text-align: center;" rowspan="3"><img src="' . $escudo . '" style="width: 60px;" class="img-fluid" alt="" align="left"></td>    
                    <td style="width:70%; text-align: center; font-size: 12px">Sistema de Coordinación Hacendaria del Estado de México con sus Municipios</td>
                    <td style="width:15%; text-align: center;" rowspan="3"> <img src="' . $administracion . '" class="img-fluid" alt="" align="right"></td>
                </tr>
                <tr>
                    <td style="text-align: center; font-size: 12px"> Manual para la Planeación, Programación y Presupuesto de Egresos Municipal ' . $anio . '</td>
                </tr>
                <tr>
                    <td style="text-align: center; font-size: 12px">&nbsp; <br> Presupuesto Basado en Resultados Municipal <br></td>
                </tr>
            </tbody>
        </table> 

        <table style="width:100%; padding: 2px;">
            <tr>
                <td style="width:80%; text-align: rigth;" rowspan="3"></td>
                <td style="width:10%; text-align: center; border:1px solid gray; font-size: 10px"> Ejercicio Fiscal:</td>
                <td style="width:10%; text-align: center; border:1px solid gray; font-size: 10px" rowspan="3">' . $anio . '</td>
            </tr>
        </table> &nbsp; <br> &nbsp;';

    $html1 = '
    <table style="width:100%;">
        <tr>
            <td style="width:35%;">
                <table style="width:100%; padding: 2px;">
                    <tr>
                        <td style="width:50%; text-align: center; border:1px solid gray; font-size: 10px">Municipio: ' . $ajustes['nombre_ente'] . '</td>
                        <td style="width:50%; text-align: center; border:1px solid gray; font-size: 10px">No.: ' . $ajustes['numero_ente'] . '</td>
                    </tr>
                    <tr>
                        <td style="width:20%; text-align: center; border:1px solid gray; font-size: 10px">PbRM-01a</td> 
                        <td style="width:80%; text-align: center; border:1px solid gray; font-size: 10px">PROGRAMA ANUAL DIMENSION ADMINISTRATIVA DEL GASTO</td> 
                    </tr>
                </table>
            </td>
            <td style="width:65%;">
                <table style="width:100%; padding: 2px;">
                    <tr>
                        <td style="width:25%; text-align: right; font-size: 10px"></td>
                        <td style="width:15%; text-align: center; border:1px solid gray; font-size: 10px"> Identificador</td>
                        <td style="width:60%; text-align: left; border:1px solid gray; font-size: 10px"> Denominacion</td>
                    </tr>
                    <tr>
                        <td style="width:25%; text-align: right; font-size: 10px">PROGRAMA PRESUPUESTARIO:</td>
                        <td style="width:15%; text-align: center; border:1px solid gray; font-size: 10px">' . $a['codigo_programa'] . '</td>
                        <td style="width:60%; text-align: left; border:1px solid gray; font-size: 10px">' . $a['nombre_programa'] . '</td>
                    </tr>
                    <tr>
                        <td style="width:25%; text-align: right; font-size: 10px">DEPENDENCIA GENERAL:</td>
                        <td style="width:15%; text-align: center; border:1px solid gray; font-size: 10px">' . $a['clave_dependencia'] . '</td>
                        <td style="width:60%; text-align: left; border:1px solid gray; font-size: 10px">' . $a['nombre_dependencia_general'] . '</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>&nbsp; <br> &nbsp; <br>&nbsp;';

    $html3 = '
        <table style="width:100%; padding: 1px; border:1px solid gray;">
            <tr>
                <td rowspan="2"style="width:4%; text-align: center; border:1px solid gray; font-size: 9px">Codigo</td>
                <td rowspan="2" style="width:41%; text-align: center; border:1px solid gray; font-size: 9px">Descripción de actividades</td>
                <td rowspan="2" style="width:10%; text-align: center; border:1px solid gray; font-size: 9px">Unidad de Medida</td>
                <td rowspan="2" style="width:9%; text-align: center; border:1px solid gray; font-size: 9px">Programado anual</td>
                <td colspan="2" style="width:9%; text-align: center; border:1px solid gray; font-size: 8px">Primero trimestre</td>
                <td colspan="2" style="width:9%; text-align: center; border:1px solid gray; font-size: 8px">Segundo Trimestre</td>
                <td colspan="2" style="width:9%; text-align: center; border:1px solid gray; font-size: 8px">Tercer Trimestre</td>
                <td colspan="2" style="width:9%; text-align: center; border:1px solid gray; font-size: 8px">Cuarto trimestre</td>
            </tr>
            <tr>
                <td style=" text-align: center; border:1px solid gray; font-size: 7px">Absoluta</td>
                <td  style=" text-align: center; border:1px solid gray; font-size: 7px">%</td>
                <td  style=" text-align: center; border:1px solid gray; font-size: 7px">Absoluta</td>
                <td style=" text-align: center; border:1px solid gray; font-size: 7px">%</td>
                <td  style=" text-align: center; border:1px solid gray; font-size: 7px">Absoluta</td>
                <td  style=" text-align: center; border:1px solid gray; font-size: 7px">%</td>
                <td  style=" text-align: center; border:1px solid gray; font-size: 7px">Absoluta</td>
                <td  style=" text-align: center; border:1px solid gray; font-size: 7px">%</td>
            </tr> 

            ' . $renglon . '
        </table>&nbsp; <br> &nbsp;';

    $html4 = '<table style="width: 100%; text-align: center; border-spacing: 3px">
<tr>
    <td style="font-size: 8px; width: 33%; border: 1px solid gray;"> ELABORÓ </td>
    <td style="font-size: 8px; width: 33%; border: 1px solid gray;"> REVISÓ </td>
    <td style="font-size: 8px; width: 33%; border: 1px solid gray;"> AUTORIZÓ </td>
</tr>	
<tr>
<td style="font-size: 8px; width: 33%; border: 1px solid gray;"><br><br><br><br><br><br>' . mb_strtoupper($a['gradoa'], 'utf-8') . ' ' . mb_strtoupper($a['nombre'], 'utf-8') . " " . mb_strtoupper($a['apellidos'], 'utf-8') . '<br>' . mb_strtoupper($a['cargo'], 'utf-8') . ' </td>
<td style="font-size: 8px; width: 33%; border: 1px solid gray;"><br><br><br><br><br><br> ' . mb_strtoupper($Director['gradoa'], 'utf-8') . ' ' . mb_strtoupper($Director['nombre'], 'utf-8') . " " . mb_strtoupper($Director['apellidos'], 'utf-8') . '<br>' . mb_strtoupper($Director['cargo'], 'utf-8') . '</td>
<td style="font-size: 8px; width: 33%; border: 1px solid gray;"><br><br><br><br><br><br>' . mb_strtoupper($DirectorUIPPE['gradoa'], 'utf-8') . ' ' . mb_strtoupper($DirectorUIPPE['nombre'], 'utf-8') . " " . mb_strtoupper($DirectorUIPPE['apellidos'], 'utf-8') . '<br>' . mb_strtoupper($DirectorUIPPE['cargo'], 'utf-8') . '</td>
</tr>	
</table>&nbsp; <br> &nbsp; <br>&nbsp;';

    $html = $html0 . $html1 . $html3 . $html4;

    $pdf->writeHTML($html);
}
// reset pointer to the last page
$pdf->lastPage();

//Close and output PDF document
$pdf->Output('02a.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+