<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>


<?php

print ceil(1/3);
print ceil(2/3);
print ceil(3/3);
print ceil(4/3);
print ceil(5/3);
print ceil(6/3);
print ceil(7/3);
print ceil(8/3);
print ceil(9/3);
print ceil(10/3);
print ceil(11/3);
print ceil(12/3);
?>

</body>
</html>