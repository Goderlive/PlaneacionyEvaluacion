<?php 
require_once 'conection.php';
function traePrograma($con, $id_area){
    $sentencia = "SELECT * FROM areas a 
    JOIN proyectos p ON p.id_proyecto = a.id_proyecto
    JOIN programas_presupuestarios pp ON pp.id_programa = p.id_programa ";
    $stm = $con->query($sentencia);
    return $programa = $stm->fetch(PDO::FETCH_ASSOC);
}

function traeFoda($con, $id_area){
    $sentencia = "SELECT * FROM ante_unob WHERE id_area = $id_area";
    $stm = $con->query($sentencia);
    return $foda = $stm->fetch(PDO::FETCH_ASSOC);
}

function traeobjetivoPDM($con, $id_objetivo){
    $sentencia = "SELECT * FROM pdm_objetivos WHERE id_objetivo = $id_objetivo";
    $stm = $con->query($sentencia);
    $objetivo = $stm->fetch(PDO::FETCH_ASSOC);
    return $objetivo['clave_objetivo'] . " " . $objetivo['nombre_objetivo'];
}

function traeoestrategia_pdm($con, $id_estrategia){
    $sentencia = "SELECT * FROM pdm_estrategias e
    LEFT JOIN pdm_objetivos o ON o.id_objetivo = e.id_objetivo
    WHERE e.id_estrategia = $id_estrategia";
    $stm = $con->query($sentencia);
    $estrategia = $stm->fetch(PDO::FETCH_ASSOC);
    return $estrategia['clave_objetivo'] . " " . $estrategia['nombre_objetivo'] . '<br>' . $estrategia['clave_estrategia']. ' ' . $estrategia['nombre_estrategia'] ;
}

function traeObjetivos_todos($con){
    $sentencia = "SELECT * FROM pdm_objetivos";
    $stm = $con->query($sentencia);
    return $objetivos = $stm->fetchAll(PDO::FETCH_ASSOC);
}

function traeObjetivoODS($con, $id_objetivo){
    $sentencia = "SELECT * FROM objetivos_ods WHERE id_objetivo = $id_objetivo";
    $stm = $con->query($sentencia);
    $objetivo = $stm->fetch(PDO::FETCH_ASSOC);
    return $objetivo['clv_objetivo'];
}

function traeEstrategias($con, $id_objetivo){
    $sentencia = "SELECT * FROM pdm_estrategias WHERE id_objetivo = $id_objetivo";
    $stm = $con->query($sentencia);
    return $estrategias = $stm->fetchAll(PDO::FETCH_ASSOC);
}

function traeIndicador($con, $id_indicador){
    $sentencia = "SELECT * FROM ante_indicadores_uso WHERE id = $id_indicador";
    $stm = $con->query($sentencia);
    return $indicadores = $stm->fetch(PDO::FETCH_ASSOC);
}

function traeLineas($con, $id_estrategia){
    $sentencia = "SELECT * FROM pdm_lineas WHERE id_estrategia = $id_estrategia";
    $stm = $con->query($sentencia);
    return $lineas = $stm->fetchAll(PDO::FETCH_ASSOC);
}

function traeProgramacionesOld($con, $id_actividad){
    $sentencia = "SELECT * FROM programaciones WHERE id_actividad = $id_actividad";
    $stm = $con->query($sentencia);
    return $programacion = $stm->fetch(PDO::FETCH_ASSOC);
}

function traeAlcanzadoOld($con, $id_actividad){
    $sentencia = "SELECT SUM(avance) AS suma FROM avances WHERE id_actividad = $id_actividad";
    $stm = $con->query($sentencia);
    return $programacion = $stm->fetch(PDO::FETCH_ASSOC);
}

function traeOEL($con, $id_linea){
    $sentencia = "SELECT * FROM pdm_lineas l
    LEFT JOIN pdm_estrategias e ON e.id_estrategia = l.id_estrategia
    LEFT JOIN pdm_objetivos o ON o.id_objetivo = e.id_objetivo  
    WHERE l.id_linea = $id_linea";
    $stm = $con->query($sentencia);
    return $oel = $stm->fetch(PDO::FETCH_ASSOC);
}

function traeODSO($con){
    $sentencia = "SELECT * FROM objetivos_ods";
    $stm = $con->query($sentencia);
    return $oel = $stm->fetchAll(PDO::FETCH_ASSOC);
}

function traeImpacto($con){
    $sentencia = "SELECT * FROM risks_impacto ORDER BY id_impacto DESC";
    $stm = $con->query($sentencia);
    return $impacto = $stm->fetchAll(PDO::FETCH_ASSOC);
}

function traeProbabilidad($con){
    $sentencia = "SELECT * FROM risks_probabilidad ORDER BY id_probabilidad DESC";
    $stm = $con->query($sentencia);
    return $probabilidad = $stm->fetchAll(PDO::FETCH_ASSOC);
}

function traeEstrategiasODS($con, $objetivo_ods){
    $sentencia = "SELECT * FROM estrategias_ods
    WHERE id_objetivo = $objetivo_ods";
    $stm = $con->query($sentencia);
    return $eODS = $stm->fetchAll(PDO::FETCH_ASSOC);
}

function traeODSyE($con, $id_estrategia){
    $sentencia = "SELECT * FROM objetivos_ods o
    JOIN estrategias_ods e ON e.id_objetivo = o.id_objetivo
    WHERE e.id_estrategia = $id_estrategia";
    $stm = $con->query($sentencia);
    return $oel = $stm->fetch(PDO::FETCH_ASSOC);
}

function traeAreasUnoB($con, $id_dependencia){
    $sentencia = "SELECT * FROM ante_areas a
    LEFT JOIN ante_unob u ON u.id_area = a.id_area
    WHERE a.id_dependencia = $id_dependencia";
    $stm = $con->query($sentencia);
    return $unoB= $stm->fetchAll(PDO::FETCH_ASSOC);
}

function traeAreeasUnoC($con, $id_dependencia){
    $sentencia = "SELECT * FROM ante_actividades a
    LEFT JOIN ante_areas ar ON ar.id_area = a.id_area
    WHERE ar.id_dependencia = $id_dependencia";
    $stm = $con->query($sentencia);
    return $unoB= $stm->fetchAll(PDO::FETCH_ASSOC);
}

function anteAreas_con($con, $id_dependencia){
    $sql = "SELECT *, a.id_area as id_area FROM areas a
        INNER JOIN dependencias_generales dp ON a.id_dependencia_general = dp.id_dependencia
        INNER JOIN dependencias_auxiliares da ON a.id_dependencia_aux = da.id_dependencia_auxiliar
        INNER JOIN proyectos py ON a.id_proyecto = py.id_proyecto
        INNER JOIN programas_presupuestarios pp ON py.id_programa = pp.id_programa
        LEFT JOIN ante_unob ab ON ab.id_area = a.id_area
        WHERE a.id_dependencia = $id_dependencia";
    $stm = $con->query($sql);
    $areas = $stm->fetchAll(PDO::FETCH_ASSOC);
    return $areas;
}

function ante_actividadesValidadas($con, $id_area){
    $sql = "SELECT * FROM ante_actividades
    WHERE id_area = $id_area";
    $stm = $con->query($sql);
    $areas = $stm->fetchAll(PDO::FETCH_ASSOC);
    return $areas;
}

function traeAreeas02a($con, $id_dependencia){
    $sentencia = "SELECT * FROM ante_actividades a
    LEFT JOIN ante_areas ar ON ar.id_area = a.id_area
    WHERE ar.id_dependencia = $id_dependencia";
    $stm = $con->query($sentencia);
    return $unoB= $stm->fetchAll(PDO::FETCH_ASSOC);
}

function traeAnteIndicadores($con, $id_dependencia){
    $sentencia = "SELECT * FROM ante_indicadores_uso i
    WHERE i.id_dependencia = $id_dependencia";
    $stm = $con->query($sentencia);
    return $unod = $stm->fetchAll(PDO::FETCH_ASSOC);
}

function traeRisks($con, $id_actividad){
    $sentencia = "SELECT * FROM risks WHERE id_actividad = $id_actividad";
    $stm = $con->query($sentencia);
    return $risks = $stm->fetch(PDO::FETCH_ASSOC);
}

function traeActividad($con, $id_actividad){
    $sentencia = "SELECT *, a.id_actividad as id_actividad FROM ante_actividades a
    LEFT JOIN ante_programaciones p ON p.id_actividad = a.id_actividad
    LEFT JOIN lineasactividades la ON la.id_actividad = a.id_actividad
    LEFT JOIN pdm_lineas pl ON pl.id_linea = la.id_linea
    LEFT JOIN pdm_estrategias pe ON pe.id_estrategia = pl.id_estrategia
    LEFT JOIN pdm_objetivos po ON po.id_objetivo = pe.id_objetivo
    WHERE a.id_actividad = $id_actividad";
    $stm = $con->query($sentencia);
    return $oel = $stm->fetch(PDO::FETCH_ASSOC);
}

function traeIndicadores($con, $id_dependencia){
    $sentencia = "SELECT * FROM ante_indicadores_uso
    WHERE id_dependencia = $id_dependencia";
    $stm = $con->query($sentencia);
    $indicadores = $stm->fetchAll(PDO::FETCH_ASSOC);
    return $indicadores;
}

function traeUnidades($con){
    $sentencia = "SELECT * FROM unidades_medida";
    $stm = $con->query($sentencia);
    $unidades = $stm->fetchAll(PDO::FETCH_ASSOC);
    return $unidades;
}

function traeActividadesDependencia($con, $id_dependencia){
    $sentencia = "SELECT * FROM ante_actividades a
    LEFT JOIN ante_areas ar ON ar.id_area = a.id_area
    LEFT JOIN ante_dependencias d ON d.id_antedependencia = ar.id_dependencia
    WHERE d.id_antedependencia = $id_dependencia
    ORDER BY a.id_area ASC";
    $stm = $con->query($sentencia);
    $actividades = $stm->fetchAll(PDO::FETCH_ASSOC);
    return $actividades;
}


function actividadesArea($con, $id_area){
    $sentencia = "SELECT * FROM ante_actividades a
    LEFT JOIN lineasactividades la ON la.id_actividad = a.id_actividad  
    LEFT JOIN pdm_lineas pl ON pl.id_linea = la.id_linea
    LEFT JOIN ante_programaciones p ON p.id_actividad = a.id_actividad
    LEFT JOIN unidades_medida u ON u.id_unidad = a.id_unidad
    WHERE a.id_area = $id_area
    GROUP BY a.id_actividad";
    $stm = $con->query($sentencia);
    return $oel = $stm->fetchAll(PDO::FETCH_ASSOC);
}




if(isset($_POST['update_foda'])){
    $id_area = $_POST['id_area'];

    $fortalezas = $_POST['fortalezas'];
    $oportunidades = $_POST['oportunidades'];
    $debilidades = $_POST['debilidades'];
    $amenazas = $_POST['amenazas'];

    
    $stm = $con->query("SELECT * FROM ante_unob WHERE id_area = $id_area");
    $id_ante_unob = $stm->fetch();

    if($id_ante_unob){
        $sql = "UPDATE ante_unob SET diagnostico_fortaleza = ?, diagnostico_oportunidad = ?, diagnostico_debilidad = ?, diagnostico_amenaza = ? WHERE id_area = $id_area";
        $sqlr = $con->prepare($sql);
        $sqlr->execute(array($fortalezas, $oportunidades, $debilidades, $amenazas));
    }else{
        $sql = "INSERT INTO ante_unob (diagnostico_fortaleza, diagnostico_oportunidad, diagnostico_debilidad, diagnostico_amenaza, id_area) VALUES (?,?,?,?,?)";
        $sqlr = $con->prepare($sql);
        $sqlr->execute(array($fortalezas, $oportunidades, $debilidades, $amenazas, $id_area));
    }

    ?>
    <form id="myForm" action="" method="get">
        <input type="hidden" name="id_area" value="<?=$id_area?>">
        <input type="hidden" name="tipo" value="b">
    </form>
    <script type="text/javascript">
        document.getElementById('myForm').submit();
    </script>
    <?php

}



if(isset($_POST['update_estrategia'])){
    $id_area = $_POST['id_area'];
    $estrategia = $_POST['estrategia'];

    $stm = $con->query("SELECT * FROM ante_unob WHERE id_area = $id_area");
    $id_ante_unob = $stm->fetch();

    if($id_ante_unob){
        $sql = "UPDATE ante_unob SET estrategia = ? WHERE id_area = $id_area";
        $sqlr = $con->prepare($sql);
        $sqlr->execute(array($estrategia));
    }else{
        $sql = "INSERT INTO ante_unob (estrategia, id_area) VALUES (?,?)";
        $sqlr = $con->prepare($sql);
        $sqlr->execute(array($estrategia, $id_area));
    }

    ?>
    <form id="myForm" action="" method="get">
        <input type="hidden" name="id_area" value="<?=$id_area?>">
        <input type="hidden" name="tipo" value="b">
    </form>
    <script type="text/javascript">
        document.getElementById('myForm').submit();
    </script>
    <?php

}


if(isset($_POST['id_linea'])){
    $id_area = $_POST['id_area'];
    $id_linea = $_POST['id_linea'];

    $stm = $con->query("SELECT * FROM ante_unob WHERE id_area = $id_area");
    $id_ante_unob = $stm->fetch();

    if($id_ante_unob){
        $sql = "UPDATE ante_unob SET linea_accion = ? WHERE id_area = $id_area";
        $sqlr = $con->prepare($sql);
        $sqlr->execute(array($id_linea));
    }else{
        $sql = "INSERT INTO ante_unob (linea_accion, id_area) VALUES (?,?)";
        $sqlr = $con->prepare($sql);
        $sqlr->execute(array($id_linea, $id_area));
    }

    ?>
    <form id="myForm" action="" method="get">
        <input type="hidden" name="id_area" value="<?=$id_area?>">
        <input type="hidden" name="tipo" value="b">
    </form>
    <script type="text/javascript">
        document.getElementById('myForm').submit();
    </script>
    <?php

}




if(isset($_POST['update_ODS'])){
    $id_area = $_POST['id_area'];
    $id_estrategia_ods = $_POST['id_estrategia_ods'];

    $stm = $con->query("SELECT * FROM ante_unob WHERE id_area = $id_area");
    $id_ante_unob = $stm->fetch();

    if($id_ante_unob){
        $sql = "UPDATE ante_unob SET id_ods = ? WHERE id_area = $id_area";
        $sqlr = $con->prepare($sql);
        $sqlr->execute(array($id_estrategia_ods));
    }else{
        $sql = "INSERT INTO ante_unob (id_ods, id_area) VALUES (?,?)";
        $sqlr = $con->prepare($sql);
        $sqlr->execute(array($id_estrategia_ods, $id_area));
    }

    ?>
    <form id="myForm" action="" method="get">
        <input type="hidden" name="id_area" value="<?=$id_area?>">
        <input type="hidden" name="tipo" value="b">
    </form>
    <script type="text/javascript">
        document.getElementById('myForm').submit();
    </script>
    <?php

}



if(isset($_POST['delete_pdm'])){
    $id_area = $_POST['id_area'];
    $id_estrategia_pdm = $_POST['linea_accion'];


    $sql = "UPDATE ante_unob SET linea_accion = NULL WHERE linea_accion = ?";
    $sqlr = $con->prepare($sql);
    $sqlr->execute(array($id_estrategia_pdm));


    ?>
    <form id="myForm" action="" method="get">
        <input type="hidden" name="id_area" value="<?=$id_area?>">
        <input type="hidden" name="tipo" value="b">
    </form>
    <script type="text/javascript">
        document.getElementById('myForm').submit();
    </script>
    <?php
}

if(isset($_POST['delete_ods'])){
    $id_area = $_POST['id_area'];
    $id_estrategia_ods = $_POST['id_ods'];


    $sql = "UPDATE ante_unob SET id_ods = NULL WHERE id_ods = ?";
    $sqlr = $con->prepare($sql);
    $sqlr->execute(array($id_estrategia_ods));


    ?>
    <form id="myForm" action="" method="get">
        <input type="hidden" name="id_area" value="<?=$id_area?>">
        <input type="hidden" name="tipo" value="b">
    </form>
    <script type="text/javascript">
        document.getElementById('myForm').submit();
    </script>
    <?php
}

if(isset($_POST['program_indicador'])){

    $id_indicador = $_POST['id_indicador'];
    
    $tipo_op_a = (isset($_POST['tipo_op_a'])) ? $_POST['tipo_op_a'] : NULL;
    $tipo_op_b = (isset($_POST['tipo_op_b'])) ? $_POST['tipo_op_b'] : NULL;
    $tipo_op_c = (isset($_POST['tipo_op_c'])) ? $_POST['tipo_op_c'] : NULL;
    $umedida_a = (isset($_POST['umedida_a'])) ? $_POST['umedida_a'] : NULL;
    $umedida_b = (isset($_POST['umedida_b'])) ? $_POST['umedida_b'] : NULL;
    $umedida_c = (isset($_POST['umedida_c'])) ? $_POST['umedida_c'] : NULL;
    $interpretacion = (isset($_POST['interpretacion'])) ? $_POST['interpretacion'] : NULL;
    $factor_de_comparacion = (isset($_POST['factor_de_comparacion'])) ? $_POST['factor_de_comparacion'] : NULL;
    $desc_factor_de_comparacion = (isset($_POST['desc_factor_de_comparacion'])) ? $_POST['desc_factor_de_comparacion'] : NULL;
    $linea_base = (isset($_POST['linea_base'])) ? $_POST['linea_base'] : NULL;
    $actividades_ids = ($_POST['id_actividades'] ? json_encode($_POST['id_actividades']) : NULL);
    $desc_meta_anual = (isset($_POST['desc_meta_anual'])) ? $_POST['desc_meta_anual'] : NULL;
    $medios_de_verificacion = (isset($_POST['medios_de_verificacion'])) ? $_POST['medios_de_verificacion'] : NULL;
    $at1 = (isset($_POST['at1'])) ? $_POST['at1'] : 0;
    $at2 = (isset($_POST['at2'])) ? $_POST['at2'] : 0;
    $at3 = (isset($_POST['at3'])) ? $_POST['at3'] : 0;
    $at4 = (isset($_POST['at4'])) ? $_POST['at4'] : 0;
    $bt1 = (isset($_POST['bt1'])) ? $_POST['bt1'] : 0;
    $bt2 = (isset($_POST['bt2'])) ? $_POST['bt2'] : 0;
    $bt3 = (isset($_POST['bt3'])) ? $_POST['bt3'] : 0;
    $bt4 = (isset($_POST['bt4'])) ? $_POST['bt4'] : 0;
    $ct1 = (isset($_POST['ct1'])) ? $_POST['ct1'] : 0;
    $ct2 = (isset($_POST['ct2'])) ? $_POST['ct2'] : 0;
    $ct3 = (isset($_POST['ct3'])) ? $_POST['ct3'] : 0;
    $ct4 = (isset($_POST['ct4'])) ? $_POST['ct4'] : 0;
    $id_alta = (isset($_POST['id_alta'])) ? $_POST['id_alta'] : NULL;
    $validado = 1;

    $sql = "UPDATE ante_indicadores_uso SET tipo_op_a = '$tipo_op_a', tipo_op_b = '$tipo_op_b', tipo_op_c = '$tipo_op_c', umedida_a = '$umedida_a', umedida_b = '$umedida_b', umedida_c = '$umedida_c', interpretacion = '$interpretacion', factor_de_comparacion = '$factor_de_comparacion', desc_factor_de_comparacion = '$desc_factor_de_comparacion', linea_base = '$linea_base', actividades_ids = '$actividades_ids', desc_meta_anual = '$desc_meta_anual', medios_de_verificacion = '$medios_de_verificacion', at1 = '$at1', at2 = '$at2', at3 = '$at3', at4 = '$at4', bt1 = '$bt1', bt2 = '$bt2', bt3 = '$bt3', bt4 = '$bt4', ct1 = '$ct1', ct2 = '$ct2', ct3 = '$ct3', ct4 = '$ct4', id_alta = '$id_alta', validado = '$validado' WHERE id = ?";
    $sqlr = $con->prepare($sql);
    $sqlr->execute(array($id_indicador));

    ?>
    <form id="myForm" action="" method="get">
        <input type="hidden" name="id_dependencia" value="<?=$id_dependencia?>">
        <input type="hidden" name="tipo" value="d">
    </form>
    <script type="text/javascript">
        document.getElementById('myForm').submit();
    </script>
    <?php
}



if(isset($_POST['actividad_update'])){

    $id_actividad = $_POST['id_actividad'];
    $id_area = $_POST['id_area'];
    $nombre_actividad = $_POST['nombre_actividad'];
    $id_unidad = $_POST['id_unidad'];

    // Aqui traemos la informacion del 08c
    $p = traeProgramacionesOld($con, $id_actividad);
    $a = traeAlcanzadoOld($con, $id_actividad);

    $programado_anual_anterior = $p['enero'] + $p['febrero'] + $p['marzo'] + $p['abril'] + $p['mayo'] + $p['junio'] + $p['julio'] + $p['agosto'] + $p['septiembre'] + $p['octubre'] + $p['noviembre'] + $p['diciembre'];
    $alcanzado_anual_anterior = $a['suma'];

    $enero = $_POST['enero'];
    $febrero = $_POST['febrero'];
    $marzo = $_POST['marzo'];
    $abril = $_POST['abril'];
    $mayo = $_POST['mayo'];
    $junio = $_POST['junio'];
    $julio = $_POST['julio'];
    $agosto = $_POST['agosto'];
    $septiembre = $_POST['septiembre'];
    $octubre = $_POST['octubre'];
    $noviembre = $_POST['noviembre'];
    $diciembre = $_POST['diciembre'];
    $validado = 1;
    
    $sql = "UPDATE ante_actividades SET validado = $validado, nombre_actividad = '$nombre_actividad', id_unidad = '$id_unidad', programado_anual_anterior = '$programado_anual_anterior', alcanzado_anual_anterior = '$alcanzado_anual_anterior' WHERE id_actividad = ?";
    $sqlr = $con->prepare($sql);
    $sqlr->execute(array($id_actividad));

    $sql = "UPDATE ante_programaciones SET enero = '$enero', febrero = '$febrero', marzo = '$marzo', abril = '$abril', mayo = '$mayo', junio = '$junio', julio = '$julio', agosto = '$agosto', septiembre = '$septiembre', octubre = '$octubre', noviembre = '$noviembre', diciembre = '$diciembre' WHERE id_actividad = ?";
    $sqlp = $con->prepare($sql);
    $sqlp->execute(array($id_actividad));

    ?>
    <form id="myForm" action="" method="get">
        <input type="hidden" name="id_area" value="<?=$id_area?>">
        <input type="hidden" name="tipo" value="a">
    </form>
    <script type="text/javascript">
        document.getElementById('myForm').submit();
    </script>
    <?php
}





if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['nueva_actividad'])){


    $id_area = $_POST['id_area'];
    $nombre_actividad = $_POST['nombre_actividad'];
    $id_unidad = $_POST['id_unidad'];
    $enero = $_POST['enero'];
    $febrero = $_POST['febrero'];
    $marzo = $_POST['marzo'];
    $abril = $_POST['abril'];
    $mayo = $_POST['mayo'];
    $junio = $_POST['junio'];
    $julio = $_POST['julio'];
    $agosto = $_POST['agosto'];
    $septiembre = $_POST['septiembre'];
    $octubre = $_POST['octubre'];
    $noviembre = $_POST['noviembre'];
    $diciembre = $_POST['diciembre'];
    $programado_anual_anterior = 0;
    $alcanzado_anual_anterior = 0;
    $validado = 1;
    
    $sql = "INSERT INTO ante_actividades (nombre_actividad, id_unidad, programado_anual_anterior, alcanzado_anual_anterior, id_area, validado) VALUES (?,?,?,?,?,?)";
    $sqlr = $con->prepare($sql);
    $sqlr->execute(array($nombre_actividad, $id_unidad, $programado_anual_anterior, $alcanzado_anual_anterior, $id_area, $validado));   
    
    $ultimoId = $con->lastInsertId();
    
    $sql = "INSERT INTO ante_programaciones (enero, febrero, marzo, abril, mayo, junio, julio, agosto, septiembre, octubre, noviembre, diciembre, id_actividad) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $sqlr = $con->prepare($sql);
    $sqlr->execute(array($enero, $febrero, $marzo, $abril, $mayo, $junio, $julio, $agosto, $septiembre, $octubre, $noviembre, $diciembre, $ultimoId));
    

    ?>
    <form id="myForm" action="" method="get">
        <input type="hidden" name="id_area" value="<?=$id_area?>">
        <input type="hidden" name="tipo" value="a">
    </form>
    <script type="text/javascript">
        document.getElementById('myForm').submit();
    </script>
    <?php
}

?>