<html>
    <header>
        <style>
            body {
                margin: 0;
                padding: 0;
            }
            .column {
            float: left;
            width: 10%;
            }
            .columnc {
            float: left;
            width: 80%;
            text-align: center;
            margin-top: 20px
            }
            .columnd {
            float: left;
            width: 10%;
            }

            .columnt {
            float: left;
            width: 40%;
            }
            .columnda {
            float: left;
            width: 60%;
            }
            .row:after {
            content: "";
            display: table;
            clear: both;
            }
            .row2:after {
            content: "";
            display: table;
            clear: both;
            }
            .center {
                text-align: center;
            }
            table, th, td {
                border: 1px solid black;
            }

        </style>
    </header>

    <body>
        <div class="row">
            <div class="column"><img src="img/logo_metepec.png" alt=""></div>
            <div class="columnc"><b>Sistema de Coordinación Hacendaria del Estado de México con sus Municipios <br>
            Guía Metodológica para el Seguimiento y Evaluación del Plan de Desarrollo Municipal 2022-2024<br><br>
            Presupuesto Basado en Resultados Municipal</b><br></div>
            <div class="columnd"><img src="img/metepec_logoc.png" alt=""></div>
        </div>

        <div class="row2">
            <div class="columnt">
                <table >
                    <tr>
                        <td> PbRM 08c </td>
                        <td class='center'> AVANCE TRIMESTRAL DE METAS DE <br> ACCION POR PROYECTO</td>
                    </tr>
                </table>
            </div>
            
            <div class="columnda"> hola</div>
        </div>
    </body>
    

    <div>

    </div>

</html>