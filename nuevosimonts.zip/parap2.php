<!DOCTYPE html>
<html>
<head>
</head>
<body>
  
<table style="width: 100%;">
  	<tbody>
	  <tr>
			<td style="width: 47%; text-align: center">Metas de Actividad Programadas y alcanzadas del Proyecto a cancelar o Reducir.
				
			</td>
			<td style="width: 6%">&nbsp;</td> 
			<td style="width: 47%; text-align: center">Metas de Actividad Programadas y alcanzadas del Proyecto que se crea o incrementa.

			</td>
    	</tr>
  	</tbody>
</table>



<tr>
	<td style="border: 1px solid black; border-collapse: collapse; text-align: center;">Inicial</td>
	<td style="border: 1px solid black; border-collapse: collapse; text-align: center;">Avance</td>
	<td style="border: 1px solid black; border-collapse: collapse; text-align: center;">Modificada</td>
	<td style="border: 1px solid black; border-collapse: collapse; text-align: center;">1</td>
	<td style="border: 1px solid black; border-collapse: collapse; text-align: center;">2</td>
	<td style="border: 1px solid black; border-collapse: collapse; text-align: center;">3</td>
	<td style="border: 1px solid black; border-collapse: collapse; text-align: center;">4</td>
	<td style="border: 1px solid black; border-collapse: collapse; text-align: center;">4</td>
	<td style="border: 1px solid black; border-collapse: collapse; text-align: center;">4</td>
	<td style="border: 1px solid black; border-collapse: collapse; text-align: center;">4</td>
</tr>

</body>
</html>
